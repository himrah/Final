from django.contrib import admin
from app.models import *
admin.site.register(Photos)
admin.site.register(Comments)
admin.site.register(ReplyComments)
admin.site.register(Profile)
admin.site.register(Profile_pic)
admin.site.register(IMG)
admin.site.register(Connection)
admin.site.register(Interest)
admin.site.register(Views)
admin.site.register(Rating)

# Register your models here.
